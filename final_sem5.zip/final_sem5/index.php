<?php

session_start();
// include("includes/database.php");
if($_SESSION['aid']==0){

  header('location:Login/login.php');
}else{ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">

    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <link rel="stylesheet" href="C:\xampp\htdocs\final sem 5 try\style.css">
    <title>Gift</title>
</head>

<body>
    <div class="introduction">
        <nav>
            <div id="logo">
                <h1>gifting app</h1>
                <svg version="1.1" id="giftSvg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px" height="30px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve">
                    <g>
                        <g>
                            <g>
                                <path class="giftPath" d="M53.5,88.1c0.3,1.3,0.2,2.7-0.5,4c-0.4,0.7-0.9,1.3-1.5,1.9c-0.3,0.3-0.7,0.6-1,0.9
                c-0.4,0.3-0.8,0.5-1.2,0.8c-3.5,2.1-9.3,3-15.1,1.2c-0.7-0.2-2.6-0.8-5.3-2c-2.7-1.2-6.2-3.1-10-6.3c-0.5-0.4-0.9-0.8-1.4-1.2
                c-0.5-0.4-0.9-0.9-1.4-1.4c-1-0.9-1.9-2-2.8-3.1c-1.8-2.3-3.5-4.8-4.9-7.7c-2.8-5.7-4.7-12.7-4.7-20.2
                c-0.1-7.5,1.9-15.6,5.8-22.9c3.9-7.3,9.8-13.7,16.9-18.6c0.9-0.7,1.8-1.2,2.7-1.8c0.9-0.5,1.9-1.1,2.8-1.6c2-0.9,3.9-2,6-2.7
                c4.1-1.7,8.5-2.7,13-3.3c1.1-0.1,2.3-0.2,3.4-0.3c1.1-0.1,2.3,0,3.4,0c2.3-0.1,4.6,0.3,6.9,0.6c4.7,0.8,9.2,2.4,13.2,4.6
                c4,2.2,7.8,4.9,11,8.3c3.3,3.4,5.9,7.5,7.5,12c1.6,4.5,2.2,9.5,1.3,14.3c-0.9,4.8-3.1,9-5.8,12.4c-1.4,1.7-2.9,3.2-4.4,4.6
                c-1.6,1.4-3.3,2.6-5,3.6c-1.7,1-3.5,1.9-5.3,2.7c-1.8,0.7-3.7,1.3-5.6,1.7c-3.7,0.8-7.6,1-11.2,0.5c-3.7-0.5-7.1-1.9-10-3.8
                c-0.7-0.5-1.4-1-2-1.5c-0.7-0.6-1.3-1.2-1.9-1.8c-1.1-1.3-2.1-2.7-2.8-4.1c-1.4-2.9-2-6.1-1.7-9c0.3-2.9,1.5-5.4,2.9-7.3
                c1.4-1.9,3-3.3,4.6-4.4c3.1-2.1,5.9-2.7,7.8-3c1.9-0.3,2.9-0.1,3,0.2c0.1,0.3-0.8,0.8-2.3,1.7c-1.5,0.9-3.8,2.1-6,4.2
                c-1.1,1.1-2.1,2.3-2.9,3.9c-0.8,1.5-1.3,3.3-1.2,5.1c0.1,3.5,2.4,7.6,6.6,9.6c4.1,2.2,9.5,2.5,14.9,0.8
                c5.3-1.7,10.7-5.3,13.9-10.1c1.6-2.4,2.7-5.1,3-7.7c0.3-2.6-0.2-5.4-1.4-8c-1.2-2.7-2.9-5.1-5.2-7.2c-2.3-2.1-5-3.9-8-5.3
                c-2.9-1.4-6-2.3-9-2.6c-1.6,0-3.2-0.3-4.8-0.1c-0.8,0.1-1.6,0-2.4,0.1l-2.4,0.3c-3.1,0.6-6.3,1.5-9.1,2.8
                c-1.5,0.6-2.8,1.4-4.2,2.2c-0.7,0.4-1.3,0.9-2,1.3c-0.7,0.4-1.3,0.8-1.9,1.4c-4.9,3.8-8.8,8.4-11.1,13.4
                c-2.4,4.9-3.4,9.9-3.1,14.6c0.2,4.7,1.6,8.8,3.3,12.1c0.9,1.6,1.9,3,2.9,4.2c1,1.1,2.1,2.2,3.2,3c2.1,1.7,4.2,2.7,5.7,3.3
                c1.5,0.6,2.6,0.9,3,1c3.2,1,6,2.2,8.5,3.7c0.3,0.2,0.6,0.4,0.9,0.6c0.3,0.2,0.6,0.4,0.9,0.6c0.6,0.4,1.1,0.9,1.6,1.4
                C52.4,85.6,53.2,86.8,53.5,88.1z" />
                            </g>
                        </g>
                    </g>
                </svg>
                <div class="burger">
                    <div class="line1"></div>
                    <div class="line2"></div>
                    <div class="line3"></div>

                </div>
            </div>
            <div class="nav-links">
                <div class="dropdown">
                    <button class="dropbtn">Ocassions</button>
                    <div class="dropdown-content">
                        <a href="C:\xampp\htdocs\final sem 5 try\birthday.html">Birthdays</a>
                        <a href="C:\xampp\htdocs\final sem 5 try\anniversary.html">Anniversary</a>
                        <a href="C:\xampp\htdocs\final sem 5 try\festival.html">Festival</a>
                        <a href="C:\xampp\htdocs\final sem 5 try\party.html">Parties & Other</a>
                    </div>
                </div>
                <a href="C:\xampp\htdocs\final sem 5 try\about.html">Top Selling</a>
                <a href="/home/mihir/Desktop/final sem 5 try/member.html">More</a>

            </div>
        </nav>
        <div class="headline">
            <img src="C:\xampp\htdocs\final sem 5 try\images\51qvGprsaFL._AC_SY700_.jpg" alt="">
            <h1>Welcome to Gift-O-City
            </h1>
            <p>Enjoy shopping :)</p>
        </div>
    </div>

    <div class="production" id="produce">
        <div class="production-intro">
            <h1>SHOP WITH US NOW</h1>
            <p>We will deliver you the best quality products</p>
        </div>
        <div class="production-gallery">
            <div class="div">
                <p>love you designer box</p>
                <img src="C:\xampp\htdocs\final sem 5 try\images\51qvGprsaFL._AC_SY700_.jpg" alt="">
            </div>
            <div class="div">
                <p>Shot by Michael Jhonson</p>
                <img src="/home/mihir/Desktop/final sem 5 try/images/61WgmV+c2TL._SY500_.jpg" alt="">
            </div>
            <div class="div">
                <p>Shot by Huwiti Rocco </p>
                <img src="/home/mihir/Desktop/final sem 5 try/images/de66e4b33716cc611fd8a9872d783222.jpg" alt="">
            </div>
            <div class="div">
                <p>Shot by Lenora Reilly </p>
                <img src="/home/mihir/Desktop/final sem 5 try/images/wine-gifts-1592510137.png" alt="">
            </div>
            <div class="div">
                <p>Shot by Ralph Sachin </p>
                <img src="/home/mihir/Desktop/final sem 5 try/images/Artboard_16_copy-100-032802.jpg" alt="">
            </div>
            <div class="div">
                <p>Shot by Odilia Iris </p>
                <img src="/home/mihir/Desktop/final sem 5 try/images/wine-gifts-1592510137.png" alt="">
            </div>


        </div>
    </div>

    <!-- car -->

    <div id="demo" class="carousel slide" data-ride="carousel">
        <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
        </ul>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="C:\xampp\htdocs\final sem 5 try\images\51qvGprsaFL._AC_SY700_.jpg" alt="MUMBAI" width="1100" height="500">
                <div class="carousel-caption">
                    <h3>MUMBAI</h3>
                    <p>OK</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="C:\xampp\htdocs\final sem 5 try\images\51qvGprsaFL._AC_SY700_.jpg" alt="ENGLAND" width="1100" height="500">
                <div class="carousel-caption">
                    <h3>PUNE</h3>
                    <p>Thank you</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="C:\xampp\htdocs\final sem 5 try\images\51qvGprsaFL._AC_SY700_.jpg" alt="AIRPORT" width="1100" height="500">
                <div class="carousel-caption">
                    <h3>MAHARASHTRA</h3>
                    <p>OK!</p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>



    <!-- car ends -->


    <footer>
        <p> @ Created by MIHIR TENDULKAR,2020</p>

    </footer>

    <script src="./dest/zenscroll-min.js"></script>
    <script src="./dest/app.js"></script>
</body>

</html>
<?php } ?>