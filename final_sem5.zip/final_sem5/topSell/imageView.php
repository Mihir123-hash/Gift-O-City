<?php
   include('dbconnection.php');
    if(isset($_GET['image_id'])) {
        $sql = "SELECT file_type,file FROM topsell WHERE id=" . $_GET['image_id'];
		$result = mysqli_query($con, $sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysqli_error($con));
		$row = mysqli_fetch_array($result);
		header("Content-type: " . $row["file_type"]);
        echo $row["file"];
	}
	mysqli_close($con);
?>