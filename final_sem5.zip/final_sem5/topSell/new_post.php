<?php
date_default_timezone_set("Asia/Calcutta");
include'dbconnection.php';
error_reporting(1);
if (isset($_POST['submit'])) {
$title = $_POST['title'];
$price = $_POST['price'];
$description  = $_POST['disc'];
$target_path ="../topSell/t_images/".basename($_FILES['photo']['name']);
$bdate = date('d-m-Y');

$query3=mysqli_query($con,"select Max(id) from topsell ");
  $row2=mysqli_fetch_array($query3);
  $cust_name=$row2[0];
  $cust_name=intval($cust_name)+1;
  $cust_name=strval($cust_name);

 if (($_FILES['my_file2']['name']!="")){
    $target_dir2 = "../topSell/t_images/";
    $file = $_FILES['my_file2']['name'];
    $path = pathinfo($file);
    $filename = $path['filename'];
    $ext = $path['extension'];
    $temp_name = $_FILES['my_file2']['tmp_name'];
    $fname2=$cust_name.".".$ext;
    $path_filename_ext = $target_dir2.$fname2;
    move_uploaded_file($temp_name,$path_filename_ext);
  }


    $query = mysqli_query($con, "insert into topsell(title, price,content,img,bdate)  
        value('$title','$price','$description','$fname2','$bdate')");
    if ($query)
     {
        $msg = "Post Updated";
    }else{
        $msg = $con->error;
    }



}


?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.0.29, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logo.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>New Post</title>
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/animatecss/animate.css">
  <link rel="stylesheet" href="assets/formstyler/jquery.formstyler.css">
  <link rel="stylesheet" href="assets/formstyler/jquery.formstyler.theme.css">
  <link rel="stylesheet" href="assets/datepicker/jquery.datetimepicker.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
  
</head>
<center>
<body>
  <div style="margin-top: 10px;">
  <?php include('header.php'); ?>

  <section class="form7 cid-s9mmJcWE5Y" id="form7-v">
    
    
    <div class="container">
        
        <div class="row justify-content-center">
            <div class="col-lg-8 mx-auto mbr-form"  >
                <form action="" method="POST" class="mbr-form form-with-styler mx-auto" data-form-title="Form Name" enctype="multipart/form-data">
                    <p class="mbr-text mbr-fonts-style align-center mb-4 display-2"> <b style="font-size: 40px">New Post</b></p>
                    <center><b><?php echo $msg;?></b></center>
                    <div class="dragArea row">
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group" data-for="title">
                            <input type="text" name="title" placeholder="Title" data-form-field="titlee" required class="form-control" value="" id="title">
                        </div><br></br>
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group" data-for="price">
                            <input type="text" name="price" placeholder="Price" data-form-field="price" required class="form-control" value="" id="price">
                        </div><br></br>
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group" data-for="discription">
                            <input type="text" name="disc" placeholder="discription" data-form-field="discription" required class="form-control" value="" id="discription">
                        </div> <br></br>
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group" data-for="image">
                            <input type="file" name="my_file2"  required class="form-control">
                        </div>
                        <br></br>
                        <div class="col-auto mbr-section-btn align-center">
                            <button type="submit" class="btn btn-primary display-4" name="submit">Upload</button>
                        </div>
                    </div>
                </form>
            </div></div>
        </div>
    </div>
</section>
</center>

  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="assets/formstyler/jquery.formstyler.js"></script>
  <script src="assets/formstyler/jquery.formstyler.min.js"></script>
  <script src="assets/datepicker/jquery.datetimepicker.full.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
   <!-- <script type="text/javascript">
   
  </script> -->
  
  <input name="animation" type="hidden">
  </body>
</html>