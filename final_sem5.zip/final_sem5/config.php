<?php
    
    $razor_pay_key_id = 'rzp_test_fA5Hs1LKjCbQ8m';
    $secret_key = '2iOhnniIuNwHpt5yJ5vqkyrb';
    define("KEY",$razor_pay_key_id);
    define("API_SECRET",$secret_key);
?>