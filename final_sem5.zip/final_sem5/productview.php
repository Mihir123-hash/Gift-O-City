<?php 
include('Login/dbconnection.php');
error_reporting(0);
if (isset($_POST['submit'])) {

$fname = $_POST['username'];
// $lname = $_POST['lastname'];
$email = $_POST['email'];
$password  = $_POST['pass'];
$contact = $_POST['contact'];
$Lane = $_POST['lane'];
$State = $_POST['state'];
$City = $_POST['city'];
$Pin = $_POST['Pincode'];

$query = mysqli_query($con, "insert into product_buy(username, email, pass, contact, lane, state, city, Pincode)  value('$fname',  '$email', '$password', '$contact', '$Lane', '$State', '$City', '$Pin')");
if ($query)
 {
	$msg = "Payment Successfull";
}else 
{
	$msg = $con->error;
}

}
// kids	
if($_GET['code']==1){
	$id=$_GET['id'];
$query=mysqli_query($con, "SELECT * FROM `kids` WHERE id='$id'");
while($val=mysqli_fetch_array($query)){
$certi="kids/k_images/".$val['img'];
$title=$val['title'];
$price= $val['price'];
$content= $val['content'];
	}
	}
// mens
if($_GET['code']==2){
	$id=$_GET['id'];
$query=mysqli_query($con, "SELECT * FROM `mens` WHERE id='$id'");
while($val=mysqli_fetch_array($query)){
$certi="mens/m_images/".$val['img'];
$title=$val['title'];
$price= $val['price'];
$content= $val['content'];	
	}	
}

// womens
if($_GET['code']==3){
	$id=$_GET['id'];
	$query=mysqli_query($con, "SELECT * FROM `womens` WHERE id='$id'");
	while($val=mysqli_fetch_array($query)){
	$certi="womens/w_images/".$val['img'];	
	$title=$val['title'];
	$price= $val['price'];
	$content= $val['content'];	
	}
}
// top sell
if($_GET['code']==4){
	$id=$_GET['id'];
	$query=mysqli_query($con, "SELECT * FROM `topsell` WHERE id='$id'");
	while($val=mysqli_fetch_array($query)){
		
	$certi="topSell/t_images/".$val['img'];
	$title=$val['title'];
	$price= $val['price'];
	$content= $val['content'];
	            
	}	

	

}
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Tailwind Profile Card Template : Tailwind Toolbox</title>
  <link rel="stylesheet" type="text/css" href="productview.css">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">

  <!-- Font Awesome if you need it
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
  -->
  <link rel="stylesheet" href="https://unpkg.com/tailwindcss/dist/tailwind.min.css"> 
   <style>
            .razorpay-payment-button{
                 background:#6c5ce7;
                 color:whitesmoke;
                 font-size:0.8rem;
                 text-transform:uppercase;
                 letter-spacing:1;
                 display:block;
                 width:15vw;
                 height:8vh;
                 border:none;
                 padding:0.3rem 0.3rem;
            }
            .img_size{
                 margin:0 auto;
                 width:180px;
                 height:180px;
            }
            figcaption{
                 text-align:center;
                 letter-spacing:1;
            }
            .card-body{
                 font-size:0.8rem;
                 font-weight:bold;
            }
        </style>
  <!--Replace with your tailwind.css once created-->

</head>

<body>
	<div style="background-image: url('images/bg-01.jpg');"></div>
	<h1><p style="text-align: center;"><b style="font-size: 40px;">product page</b></p></h1>
	 <div class="card" style="margin-right: 50%; margin-top: 6% ;margin-left: 20%">
  <img src="<?php echo $certi; ?>" alt="random" style="width:100%">
  <h1><?php echo $title; ?></h1>
  <p class="price"><?php echo $price; ?></p>
  <p><?php echo $content; ?></p>

   


 
  
</div> 
<br></br>
<form class="login100-form validate-form border:orange; border-width:5px; border-style:solid;" action="" method="POST" style="margin-left: 20%">
					<span class="login100-form-title p-b-60">
						<b style="font-size: 40px;margin-left: 10%">Details</b>
					</span>

					<center><b><?php echo $msg;?></b></center>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Username is reauired">
						
						<input class="input100" type="text" name="username" placeholder="Type your firstname">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<!-- <div class="wrap-input100 validate-input m-b-23" data-validate = "lastname is reauired">
						
						<input class="input100" type="text" name="lastname" placeholder="Type your lastname">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div> -->

					<div class="wrap-input100 validate-input m-b-23" data-validate = "email is reauired">
						
						<input class="input100" type="email" name="email" placeholder="Type your email">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Password is required">
						
						<input class="input100" type="password" name="pass" placeholder="Type your password">
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "contact is reauired">
						
						<input class="input100" type="text" name="contact" placeholder="Type your contact">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "lane is reauired">
						
						<input class="input100" type="text" name="lane" placeholder="Type your lane">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "state is reauired">
						
						<input class="input100" type="text" name="state" placeholder="Type your state">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "city is reauired">
						
						<input class="input100" type="text" name="city" placeholder="Type your city">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "pincode is reauired">
						
						<input class="input100" type="text" name="Pincode" placeholder="Type your [pincode]">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>
					
					</div>

<input type="submit" name="submit" >

					
					
				</form>
<br></br>

				<p style="margin-left: 20%" > <a href="javascript:void(0)"  class="btn btn-sm btn-primary float-center buy_now " name="submit" data-amount="<?php echo $price; ?>" data-id="2" ><button >Buy Now</button></a> </p>




<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
  
  $('body').on('click', '.buy_now', function(e){
    var totalAmount = $(this).attr("data-amount");
    var product_id =  $(this).attr("data-id");
    var contact_number = $("#contact").attr("value");
    var options = {
    "key": "rzp_test_fA5Hs1LKjCbQ8m",
    "amount": totalAmount * 100, // 2000 paise = INR 20
    "name": "E-Commerce",
    "description": " Gift_O_City Payment Cart",
    "currency":"INR",
    "image": "./Landing-Page-master/hero.png",
    "handler": function (response){
            $.ajax({
            url: 'razorPaySuccess.php',
            type: 'post',
            data: {
                razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id,
            }, 
            success: function (msg) {
               
               window.location.href = 'thankyou.php';
            }
        });
      
    },
 
    "theme": {
        "color": "#528FF0"
    }
  };
  var rzp1 = new Razorpay(options);
   rzp1.open();
  e.preventDefault();
  });
 
</script>
</body>

